<!--<div id="footer">
  <div class="container text-center">
    <div class="fnav">
      <p>Copyright &copy; 2016 Spectrum. Designed by <a href="http://www.templatewire.com" rel="nofollow">TemplateWire</a></p>
    </div>
  </div>
</div>
<script type="text/javascript" src="js/jquery.1.11.1.js"></script> 
<script type="text/javascript" src="js/bootstrap.js"></script> 
<script type="text/javascript" src="js/SmoothScroll.js"></script> 
<script type="text/javascript" src="js/nivo-lightbox.js"></script> 
<script type="text/javascript" src="js/jquery.isotope.js"></script> 
<script type="text/javascript" src="js/jqBootstrapValidation.js"></script> 
 
<script type="text/javascript" src="js/main.js"></script>
</body>
</html>-->


<div id="footer">
  <div class="container text-center">
    <div class="fnav">
      <p>Copyright &copy; 2016 Spectrum. Designed by <a href="http://www.templatewire.com" rel="nofollow">TemplateWire</a></p>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.1.11.1.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('js/SmoothScroll.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('js/nivo-lightbox.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('js/jquery.isotope.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('js/jqBootstrapValidation')); ?>.js"></script> 
 
<script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>

</body>
</html>
