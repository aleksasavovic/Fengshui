<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1> Ovo je iz login.blade, uAuthenticatesUsers je stavljeno da vraca ovo za loginFormu</h1>
</body>
</html>