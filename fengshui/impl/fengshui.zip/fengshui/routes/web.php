<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\User;


Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

//rute za proifl korisnika:
Route::get('/profiles/myProfile', 'ProfileController@index')->name('myProfile');
Route::post('/profiles/myProfile', 'ProfileController@store')->name('changeInfo');
Route::get('/changePass', function() {
	return view('changePass');
})->name('changePassForm');

Route::post('/changePass', 'ProfileController@changePassword')->name('changePass');


//dizajn:
Route::get('/dizajniranje', function () {
    return view('dizajniranje');
})->name('dizajn');

//galerija:
//Route::get('/gallery', 'HomeController@showGallery')->name('showGallery');
Route::get('/gallery', function(){
	$users = User::all();
    return view('gallery')->with('users', $users);
 })->name('showGallery');
 
//pretraga:
Route::post('/profiles/search', 'SearchController@search')->name('search');
Route::get('/profiles/{id}', 'ProfileController@show');
Route::post('/profiles/{id}', 'ProfileController@update');